package com.redditstorymaker.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class RedditStoryMakerApp : Application() {
    companion object {
        const val EXPORT_CHANNEL_ID = "video_export_channel"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                EXPORT_CHANNEL_ID,
                "Video Rendering Progress",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows progress during MP4 video rendering & hardware encoding"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }
}
