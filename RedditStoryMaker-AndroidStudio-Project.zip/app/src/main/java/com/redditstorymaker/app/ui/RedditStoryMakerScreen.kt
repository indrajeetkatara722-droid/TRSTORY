package com.redditstorymaker.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RedditStoryMakerScreen() {
    var storyText by remember { mutableStateOf("I never thought my sister would try to steal my wedding day...") }
    var selectedGenre by remember { mutableStateOf("AITA") }
    var selectedLanguage by remember { mutableStateOf("English (US)") }
    var isGenerating by remember { mutableStateOf(false) }
    var exportProgress by remember { mutableStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Reddit Story Maker",
                        color = Color(0xFFFF4500),
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF141416))
            )
        },
        containerColor = Color(0xFF0E1012)
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 9:16 Video Preview Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(320.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A1C1E))
            ) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "9:16 Vertical Preview\n(Minecraft / Runner + Captions)",
                        color = Color.Gray,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            }

            // Quick Actions
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { /* Preview Audio */ },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2F33)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Preview")
                }
                Button(
                    onClick = { /* Render Video */ },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4500)),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Render MP4")
                }
            }

            // Story Text
            Text("Story Script", color = Color(0xFFFF4500), fontWeight = FontWeight.SemiBold)
            OutlinedTextField(
                value = storyText,
                onValueChange = { storyText = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFFFF4500),
                    unfocusedBorderColor = Color(0xFF3A3F45)
                )
            )

            // Generator Button
            Button(
                onClick = { isGenerating = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF4500)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (isGenerating) "AI Generating..." else "Generate AI Story")
            }
        }
    }
}
