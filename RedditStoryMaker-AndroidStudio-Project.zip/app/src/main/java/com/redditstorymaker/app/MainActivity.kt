package com.redditstorymaker.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.graphics.Color
import com.redditstorymaker.app.ui.RedditStoryMakerScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val redditDarkColors = darkColorScheme(
                primary = Color(0xFFFF4500), // Reddit Orange
                onPrimary = Color.White,
                secondary = Color(0xFFFF5722),
                background = Color(0xFF0E1012),
                surface = Color(0xFF1A1C1E),
                onBackground = Color(0xFFF3ECE4),
                onSurface = Color(0xFFF3ECE4)
            )

            MaterialTheme(colorScheme = redditDarkColors) {
                RedditStoryMakerScreen()
            }
        }
    }
}
