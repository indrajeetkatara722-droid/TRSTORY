package com.redditstorymaker.app.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Manages Native Android TextToSpeech and Cloud AI TTS.
 * Generates WAV audio files with word timestamps for precise caption sync.
 */
class VoiceSynthesizer(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var isInitialized = false

    fun init(onReady: () -> Unit) {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                isInitialized = true
                onReady()
            }
        }
    }

    suspend fun synthesizeSpeechToFile(text: String, outputFile: File, speechRate: Float = 1.1f): Boolean {
        if (!isInitialized || tts == null) return false

        return suspendCancellableCoroutine { continuation ->
            tts?.setSpeechRate(speechRate)
            val utteranceId = "utterance_${System.currentTimeMillis()}"

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}

                override fun onDone(id: String?) {
                    continuation.resume(true)
                }

                override fun onError(id: String?) {
                    continuation.resume(false)
                }
            })

            tts?.synthesizeToFile(text, null, outputFile, utteranceId)
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
    }
}
